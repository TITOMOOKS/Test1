package uchicago;

public class UChicagoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String []  stringlist = {"red", "red", "blue", "yellow", "blue", "yellow", "green"};
			int n = 2;
			
	//			* returns: ['red', 'blue']
			findduplicates(stringlist,n);

	}
	
	public static void findduplicates (String [] listofstring, int x)
	{
		int i=0, j=0; x=1;
		int n = listofstring.length;
		String [] newstring = listofstring;
		for (i=0 ; i<n; i=i+x)
		{
			for (j=0; j<n; j++)
			{
			if (newstring[i].contentEquals(listofstring[j]) && i!=j)
				
				System.out.println("duplicate string is" + newstring[i]);
			
			}
			x++;
		}
	}

}
