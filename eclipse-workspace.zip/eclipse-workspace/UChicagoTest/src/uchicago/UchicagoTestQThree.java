package uchicago;


public class UchicagoTestQThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String[] string1 =	{"(",")", "(", ")","(", ")"} ;// is balanced
	String[] string2 =	{"(",")", "(",")", ")","(", ")"} ;// not balanced
	
	if (equals(string1) == true)
		System.out.println("string1 is balanced" );
	if (equals(string2) == false)
		System.out.println("string2 is unbalanced" );
	
	}

	public static boolean equals(String [] paren) {
		
		String left = "(";
		String right = ")";
		
		int i=0 ,j=0, n= paren.length;
		int counti=0, countj=0;
		for (i=0, j=0; i<n; i++,j++)
		{
			if (paren[i].equals(left))
				counti++;
			if (paren[j].equals(right))
				countj++;
		}
		if (counti==countj)
        return true;
		else
			return false;
    }
}
