package newpackage;

public class MyClass {

}
